import Hybrid.Form

structure Eval (N : Set ℕ) where
  f  : Form N → Bool
  p1 : f ⊥ = false
  p2 : ∀ φ ψ : Form N, (f (φ ⟶ ψ) = true) ↔ (¬(f φ) = true ∨ (f ψ) = true)

def Tautology (φ : Form N) : Prop := ∀ e : Eval N, e.f φ = true

theorem tautology_nom_subst {φ : Form N} (h : Tautology φ) (new old : NOM N) :
    Tautology (φ[new // old]) := by
  intro e
  let f : Form N → Bool := fun ψ => e.f (ψ[new // old])
  have p1 : f ⊥ = false := by simp [f, nom_subst_nom, e.p1]
  have p2 : ∀ ψ χ, f (ψ ⟶ χ) = true ↔ (¬ f ψ = true ∨ f χ = true) := by
    intro ψ χ
    show e.f ((ψ ⟶ χ)[new // old]) = true ↔ _
    simp only [nom_subst_nom, f]
    exact e.p2 (ψ[new // old]) (χ[new // old])
  exact h ⟨f, p1, p2⟩

theorem e_dn {e : Eval N} : e.f (∼φ) = false ↔ e.f φ = true := by
  rw [Form.neg, ← Bool.not_eq_true, e.p2, e.p1]
  simp [Bool.not_eq_true]

theorem e_neg {e : Eval N} : e.f (∼φ) = true ↔ e.f φ = false := by
  have c := @not_congr (e.f (∼φ) = false) (e.f φ = true) e_dn
  rw [Bool.not_eq_false, Bool.not_eq_true] at c
  exact c

theorem e_conj {e : Eval N} : e.f (φ ⋀ ψ) = true ↔ (e.f φ = true ∧ e.f ψ = true) := by
  rw [Form.conj, ←Bool.not_eq_false, e_dn, e.p2, not_or, not_not, Bool.not_eq_true, e_dn]

theorem e_disj {e : Eval N} : e.f (φ ⋁ ψ) = true ↔ (e.f φ = true ∨ e.f ψ = true) := by
  rw [Form.disj, e.p2, Bool.not_eq_true, e_dn]

theorem e_impl {e : Eval N} : e.f (φ ⟶ ψ) = true ↔ (e.f φ = true → e.f ψ = true) := by
  simp only [e.p2, implication_disjunction]

syntax "eval" : tactic
macro_rules
  | `(tactic| eval) => `(tactic| intro e; simp [e.p1, e.p2, e_dn, e_neg, e_conj, e_disj, e_impl, -Form.neg, -Form.conj, -Form.disj, -Form.iff])

theorem hs_taut : Tautology ((φ ⟶ ψ) ⟶ (ψ ⟶ χ) ⟶ (φ ⟶ χ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem ax_1 : Tautology (φ ⟶ ψ ⟶ φ) := by
  intro e
  simp only [e.p2, Bool.not_eq_true, or_comm, ←or_assoc, Bool.dichotomy, true_or]

theorem neg_conj : Tautology ((φ ⟶ ∼ψ) ⟷ ∼(φ ⋀ ψ)) := by
  simp
  eval

theorem contrapositive : Tautology ((φ ⟶ ψ) ⟶ (∼ψ ⟶ ∼φ)) := by
  eval
  simp only [or_comm]
  simp only [and_or_right]
  apply And.intro
  . rw [←or_assoc, ←Bool.not_eq_true]
    apply Or.inl
    apply em
  . rw [←or_comm, or_assoc, or_comm, ←Bool.not_eq_true]
    apply Or.inl
    apply em

theorem contrapositive' : Tautology ((∼ψ ⟶ ∼φ) ⟶ (φ ⟶ ψ)) := by
  eval
  simp only [or_comm]
  simp only [and_or_right]
  apply And.intro
  . rw [←or_assoc, ←Bool.not_eq_true]
    apply Or.inl
    rw [or_comm]
    apply em
  . rw [←or_comm, or_assoc, or_comm, ←Bool.not_eq_true]
    apply Or.inl
    rw [or_comm]
    apply em

theorem neg_intro : Tautology ((φ ⟶ ψ) ⟶ (φ ⟶ ∼ψ) ⟶ ∼φ) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem imp_refl : Tautology (φ ⟶ φ) := by
  eval

theorem imp_neg : Tautology (∼(φ ⟶ ψ) ⟷ (φ ⋀ ∼ψ)) := by
  simp only [Form.iff, Form.conj, Form.neg]
  eval

theorem dne : Tautology (∼∼φ ⟶ φ) := by
  eval

theorem dni : Tautology (φ ⟶ ∼∼φ) := by
  eval

theorem dn : Tautology (φ ⟷ ∼∼φ) := by
  intro e
  rw [Form.iff, e_conj]
  exact ⟨dni e, dne e⟩ 

theorem conj_intro : Tautology (φ ⟶ ψ ⟶ (φ ⋀ ψ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem conj_intro_hs : Tautology ((φ ⟶ ψ) ⟶ (φ ⟶ χ) ⟶ (φ ⟶ (ψ ⋀ χ))) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem conj_elim_l : Tautology ((φ ⋀ ψ) ⟶ φ) := by
  eval
  simp [←or_assoc, or_comm, Bool.dichotomy]

theorem conj_elim_r : Tautology ((φ ⋀ ψ) ⟶ ψ) := by
  eval
  simp [or_assoc, Bool.dichotomy]

theorem conj_comm_t : Tautology ((φ ⋀ ψ) ⟶ (ψ ⋀ φ)) := by
  intro e
  simp only [e_impl, e_conj]
  tauto

theorem conj_comm_t' : Tautology (∼(φ ⋀ ψ) ⟶ ∼(ψ ⋀ φ)) := by
  intro e
  simp only [e_impl, e_neg, ← Bool.not_eq_true, e_conj]
  tauto

theorem iff_intro : Tautology ((φ ⟶ ψ) ⟶ (ψ ⟶ φ) ⟶ (φ ⟷ ψ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem iff_elim_l : Tautology ((φ ⟷ ψ) ⟶ (φ ⟶ ψ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem iff_elim_r : Tautology ((φ ⟷ ψ) ⟶ (ψ ⟶ φ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem iff_rw : Tautology ((φ ⟷ ψ) ⟶ (ψ ⟷ χ) ⟶ (φ ⟷ χ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem iff_imp : Tautology ((φ ⟷ ψ) ⟶ (χ ⟷ τ) ⟶ ((φ ⟶ χ) ⟷ (ψ ⟶ τ))) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem taut_iff_mp : Tautology (φ ⟷ ψ) → Tautology (φ ⟶ ψ) := by
  rw [Form.iff]
  intro h e
  have := h e
  rw [e_conj] at this
  exact this.left

theorem taut_iff_mpr : Tautology (φ ⟷ ψ) → Tautology (ψ ⟶ φ) := by
  rw [Form.iff]
  intro h e
  have := h e
  rw [e_conj] at this
  exact this.right

theorem disj_intro_l : Tautology (φ ⟶ (φ ⋁ ψ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem disj_intro_r : Tautology (φ ⟶ (ψ ⋁ φ)) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem disj_elim : Tautology ((φ ⋁ ψ) ⟶ (φ ⟶ χ) ⟶ (ψ ⟶ χ) ⟶ χ) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

theorem idem : Tautology ((χ ⟶ ψ ⟶ ψ ⟶ φ) ⟶ (χ ⟶ ψ ⟶ φ)) := by
  intro e
  simp only [e_impl]
  tauto

theorem exp : Tautology (((φ ⋀ ψ) ⟶ χ) ⟶ (φ ⟶ ψ ⟶ χ)) := by
  intro e
  simp only [e_impl, e_conj]
  tauto

theorem imp : Tautology ((φ ⟶ ψ ⟶ χ) ⟶ ((φ ⋀ ψ)) ⟶ χ) := by
  intro e
  simp only [e_impl, e_conj]
  tauto

theorem impexp : Tautology (((φ ⋀ ψ) ⟶ χ) ⟷ (φ ⟶ ψ ⟶ χ)) := by
  intro e
  rw [Form.iff, e_conj]
  exact ⟨exp e, imp e⟩

theorem com12 : Tautology ((φ ⟶ (ψ ⟶ χ)) ⟶ (ψ ⟶ (φ ⟶ χ))) := by
  intro e
  simp only [e_impl]
  intro h1 h2 h3
  exact h1 h3 h2

theorem mp_help : Tautology ((a ⟶ (φ ⟶ ψ)) ⟶ ((b ⟶ φ) ⟶ (a ⟶ b ⟶ ψ))) := by
  intro e
  simp only [Form.iff, e_impl, e_neg, e_conj, e_disj, ← Bool.not_eq_true]
  tauto

def Eval.nom_variant (e e' : Eval N) (i : NOM N) (x : SVAR) : Prop :=
  e'.f = (λ φ : Form N => if φ = i then (e.f x) else (e.f φ))

theorem iff_not : Tautology ((φ ⟷ ψ) ⟷ (∼φ ⟷ ∼ψ)) := by
  simp only [Form.iff, Form.conj, Form.neg]
  eval
 
theorem imp_taut (h : Tautology φ) : Tautology ((φ ⟶ ψ) ⟶ ψ) := by
  unfold Tautology at h ⊢
  intro e
  have := h e
  simp [this, e.p1, e.p2, e_dn, e_neg, e_conj, e_disj, e_impl, -Form.neg, -Form.conj, -Form.disj, -Form.iff]
